document.addEventListener('DOMContentLoaded', (event) => {
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightbox-image');
    const close = document.getElementsByClassName('close')[0];
    
    document.querySelectorAll('.grid-item img').forEach(image => {
        image.addEventListener('click', () => {
            lightbox.style.display = 'block';
            lightboxImage.src = image.src;
        });
    });

    close.addEventListener('click', () => {
        lightbox.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target == lightbox) {
            lightbox.style.display = 'none';
        }
    });
});
